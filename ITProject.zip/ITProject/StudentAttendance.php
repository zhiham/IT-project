<?php
session_start();
$dark_mode = $_SESSION['dark_mode'] ?? false;
$language = $_SESSION['language'] ?? 'English';
$font_size = $_SESSION['font_size'] ?? '16px';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title data-translate="SUN ROOM STUDENT PORTAL">SUN ROOM STUDENT PORTAL</title>
    <link rel="stylesheet" href="mainpage.css">
    <link rel="stylesheet" href="navigation.css">
    <link rel="stylesheet" href="studentcard.css">
    <link rel="stylesheet" href="StudentAttendance.css">
	<link rel="stylesheet" href="settings.css">
	
	<script>
  const savedFontSize = localStorage.getItem('fontSize') || '16px';
  document.documentElement.style.fontSize = savedFontSize;
</script>
</head>

<body class="<?= $dark_mode ? 'dark-mode' : '' ?>" style="font-size: <?= $font_size ?>;">

<nav>
    <div class="navigation">
        <div class="left-section">
            <a href="LoginPage.php"><img class="logo" src="pictures/logo.png"></a>
        </div>

        <div class="middle-section-search">
            <input class="searchbar" type="text" name="search" placeholder="Search">
            <button class="searchimgbutton">
                <img class="searchimg" src="pictures/icons/search.jpg">
            </button>
        </div>

        <div class="right-section-Attendance">
            <div class="navigation-div">
                <a href="Timetable.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/timetable.png"></button></a>
                <span class="navigation-text-attendance" data-translate="Timetable">Timetable</span>
            </div>
            <div class="navigation-div">
                <a href="StudentAttendance.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/attendance.png"></button></a>
                <span class="navigation-text-attendance" data-translate="Attendance">Attendance</span>
            </div>
            <div class="navigation-div">
                <a href="StudentDashboard.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/dashboard.png"></button></a>
                <span class="navigation-text-attendance" data-translate="Dashboard">Dashboard</span>
            </div>
            <div class="navigation-div">
                <a href="Profile.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/more.png"></button></a>
                <span class="navigation-text-attendance" data-translate="Profile">Profile</span>
            </div>
        </div>
    </div>
</nav>

<br>

<div class="container"></div>

<div class="tables-container">
    <div class="semester-tables">
        <?php
        $semesters = [
            "Semester 1" => [
                "Discrete Mathematics" => "95%",
                "Programming Concepts" => "93%",
                "Web Design" => "96%",
                "Database Fundamental I" => "90%",
                "Operating Systems" => "92%",
                "System Analysis & Design" => "91%",
            ],
            "Semester 2" => [
                "Probability & Statistics" => "94%",
                "Java Programming" => "92%",
                "Data Communication" => "95%",
                "Web Development" => "90%",
                "Database Fundamental II" => "89%",
            ],
            "Semester 3" => [
                "Basic Linear Algebra" => "97%",
                "Fundamentals of IS" => "93%",
                "Mobile Application" => "91%",
                "IT Project (Part I)" => "94%",
            ],
            "Semester 4" => [
                "Elementary Calculus" => "95%",
                "Network & Security" => "96%",
                "Professional Issues in IT" => "94%",
                "Object-Oriented Modelling" => "97%",
                "System Architecture" => "92%",
            ],
            "Semester 5" => [
                "AI & Machine Learning" => "89%",
                "Cybersecurity Principles" => "91%",
                "Data Science" => "90%",
            ],
            "Semester 6" => [
                "Internship" => "100%",
                "Final Year Project" => "95%",
            ],
        ];

        foreach ($semesters as $semester => $subjects) {
            echo '<div class="attendance-card">';
            echo '<div class="attendance-semester" data-translate="'.$semester.'">'.$semester.'</div>';
            foreach ($subjects as $subject => $percent) {
                echo '<div class="attendance-row"><span data-translate="'.$subject.'">'.$subject.'</span><span>'.$percent.'</span></div>';
            }
            echo '</div>';
        }
        ?>
    </div>

    <div class="details-table">
        <table class="timetableAttendanceIntake enhanced-intake-table">
            <thead>
                <tr>
                    <th colspan="2">
                        <div class="intake-header">
                            <label for="intake-select" class="intake-label" data-translate="Select Intake Code">📘 Select Intake Code:</label>
                            <select id="intake-select" class="intake-dropdown">
                                <option value="">DIIT0124</option>
                                <option value="">DIIT042024</option>
                                <option value="">DIIT092024</option>
                            </select>
                        </div>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="2">
                        <div class="attendance-summary-card">
                            <h3 class="attendance-summary-title" data-translate="Overall Intake Attendance">🎯 Overall Intake Attendance</h3>
                            <a href="StudentAttendanceOTP.php">
                                <button class="button-82-pushable" role="button">
                                    <span class="button-82-shadow"></span>
                                    <span class="button-82-edge"></span>
                                    <span class="button-82-front text" data-translate="Sign Attendance">✅ Sign Attendance</span>
                                </button>
                            </a>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>

        <div class="logout-button-div">
            <a href="settings.php"><button class="button-44" role="button" data-translate="Settings">Settings</button></a>
            <button class="button-44" role="button" data-translate="Logout">Logout</button>
        </div>
    </div>
</div>

<script src="settings.js"></script>
</body>
</html>
