<?php
session_start();
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;
$language = isset($_SESSION['language']) ? $_SESSION['language'] : 'English';
$font_size = isset($_SESSION['font_size']) ? $_SESSION['font_size'] : '16px';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title data-translate="SUN ROOM STUDENT PORTAL">SUN ROOM STUDENT PORTAL</title>
    <link rel="stylesheet" href="mainpage.css">
    <link rel="stylesheet" href="navigation.css">
    <link rel="stylesheet" href="studentcard.css">
    <link rel="stylesheet" href="OTP.css">
	<link rel="stylesheet" href="settings.css">
</head>

<body class="<?= $dark_mode ? 'dark-mode' : '' ?>" style="font-size: <?= $font_size ?>;">

    <!-- Navigation -->
    <nav>
        <div class="navigation">
            <div class="left-section">
                <a href="LoginPage.php"><img class="logo" src="pictures/logo.png"></a>
            </div>

            <div class="middle-section-search">
                <input class="searchbar" type="text" name="search" placeholder="Search">
                <button class="searchimgbutton">
                    <img class="searchimg" src="pictures/icons/search.jpg">
                </button>
            </div>

            <div class="right-section-Attendance">
                <div class="navigation-div">
                    <a href="Timetable.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/timetable.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Timetable">Timetable</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentAttendance.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/attendance.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Attendance">Attendance</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentDashboard.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/dashboard.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Dashboard">Dashboard</span>
                </div>
                <div class="navigation-div">
                    <a href="Profile.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/profile.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Profile">Profile</span>
                </div>
            </div>
        </div>
    </nav>

    <br>

    <!-- Main OTP Section -->
    <div class="container">
        <div class="otp-wrapper">
            <div class="Attendance-OTP-Box">
                <div class="Number"><input type="text" maxlength="1" class="otp-input" /></div>
                <div class="Number"><input type="text" maxlength="1" class="otp-input" /></div>
                <div class="Number"><input type="text" maxlength="1" class="otp-input" /></div>
            </div>

            <div class="button-container">
                <button class="button-82-pushable" role="button">
                    <span class="button-82-shadow"></span>
                    <span class="button-82-edge"></span>
                    <span class="button-82-front text" data-translate="Enter OTP">Enter OTP</span>
                </button>
            </div>
        </div>

        <!-- Profile Info -->
        <div class="profile-dive">
            <div class="profile-card">
                <div class="profile-header">
                    <p class="profile-name">Kishen Austin Nair 2304885</p>
                </div>
                <div class="profile-body">
                    <div class="profile-photo">
                        <img src="pictures/studentpics/kishenAN.jpg" alt="Profile Photo">
                    </div>
                    <div class="profile-info">
                        <p class="ProfileInfo"><b data-translate="Programme:">Programme:</b> <span data-translate="Diploma In Information Technology">Diploma In Information Technology</span></p>
                        <p class="ProfileInfo"><b data-translate="Intake:">Intake:</b> <span data-translate="April 2024">April 2024</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="settings.js"></script>
</body>
</html>
