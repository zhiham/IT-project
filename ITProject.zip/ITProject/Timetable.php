<?php
session_start();
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;
$language = isset($_SESSION['language']) ? $_SESSION['language'] : 'English';
$font_size = isset($_SESSION['font_size']) ? $_SESSION['font_size'] : '16px';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title data-translate="Timetable">Timetable - SUN ROOM STUDENT PORTAL</title>
    <link rel="stylesheet" href="mainpage.css">
    <link rel="stylesheet" href="navigation.css">
    <link rel="stylesheet" href="studentcard.css">
    <link rel="stylesheet" href="Timetable.css">
	<link rel="stylesheet" href="settings.css">
</head>

<body class="<?= $dark_mode ? 'dark-mode' : '' ?>" style="font-size: <?= $font_size ?>;">

    <!-- Navigation bar -->
    <nav>
        <div class="navigation">
            <div class="left-section">
                <a href="LoginPage.php"><img class="logo" src="pictures/logo.png" alt="Logo"></a>
            </div>
            <div class="middle-section-search">
                <input class="searchbar" type="text" name="search" placeholder="Search">
                <button class="searchimgbutton">
                    <img class="searchimg" src="pictures/icons/search.jpg">
                </button>
            </div>
            <div class="right-section-Attendance">
                <div class="navigation-div">
                    <a href="Timetable.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/timetable.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Timetable">Timetable</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentAttendance.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/attendance.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Attendance">Attendance</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentDashboard.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/dashboard.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Dashboard">Dashboard</span>
                </div>
                <div class="navigation-div">
                    <a href="Profile.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/more.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Profile">Profile</span>
                </div>
            </div>
        </div>
    </nav>

    <br>

    <!-- Main content -->
    <div class="container">
        <div class="logout-button-div">
            <button class="button-44" data-translate="Settings">Settings</button>
            <button class="button-44" data-translate="Logout">Logout</button>
        </div>

        <div class="dropdown-arrow">
            <select>
                <option data-translate="Select Course">Select Course</option>
                <option>DIIT 012024</option>
                <option>DIIT 042024</option>
                <option>DIIT 092024</option>
            </select>

            <select>
                <option data-translate="Select Week">Select Week</option>
                <option>19 May 2025</option>
                <option>26 May 2025</option>
                <option>2 June 2025</option>
            </select>

            <select>
                <option data-translate="Sort By">Sort By</option>
                <option value="name" data-translate="Name A-Z">Name (A-Z)</option>
                <option value="ageAsc" data-translate="Age Low to High">Age (Low to High)</option>
                <option value="ageDesc" data-translate="Age High to Low">Age (High to Low)</option>
            </select>
        </div>

        <!-- Timetable -->
        <table class="timetable">
            <tbody>
                <tr>
                    <th class="Weekday" data-translate="Monday">Monday</th>
                    <td>
                        <b data-translate="Module Code:">Module Code:</b> DDS2133<br>
                        <b data-translate="Location:">Location:</b> Auditorium 3<br>
                        <b data-translate="Module Name:">Module Name:</b> ELEMENTARY CALCULUS<br>
                        <b data-translate="Lecturer:">Lecturer:</b> DR NOR AFIFAH HANIM BINTI ZULKEFLI<br>
                        <b data-translate="Time:">Time:</b> 08:00 AM - 09:00 AM<br>
                    </td>
                    <td>
                        <b data-translate="Module Code:">Module Code:</b> DIT2133<br>
                        <b data-translate="Location:">Location:</b> Auditorium 3<br>
                        <b data-translate="Module Name:">Module Name:</b> COMPUTER SYSTEM ARCHITECTURE<br>
                        <b data-translate="Lecturer:">Lecturer:</b> DHARMIDRAN ANANTHARSEKARAN<br>
                        <b data-translate="Time:">Time:</b> 12:00 PM - 01:00 PM<br>
                    </td>
                </tr>
                <tr>
                    <th class="Weekday" data-translate="Tuesday">Tuesday</th>
                    <td>
                        <b data-translate="Module Code:">Module Code:</b> DIT1343<br>
                        <b data-translate="Location:">Location:</b> Auditorium 3<br>
                        <b data-translate="Module Name:">Module Name:</b> PROFESSIONAL ISSUES IN IT<br>
                        <b data-translate="Lecturer:">Lecturer:</b> HASBULLAH OSMAN<br>
                        <b data-translate="Time:">Time:</b> 01:00 PM - 02:00 PM<br>
                    </td>
                    <td>
                        <b data-translate="Module Code:">Module Code:</b> DIT1233<br>
                        <b data-translate="Location:">Location:</b> Auditorium 3<br>
                        <b data-translate="Module Name:">Module Name:</b> NETWORK ADMINISTRATION & SECURITY<br>
                        <b data-translate="Lecturer:">Lecturer:</b> SYUHADA AZWA SELIMI<br>
                        <b data-translate="Time:">Time:</b> 02:00 PM - 03:00 PM<br>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Load language + settings script -->
    <script src="settings.js"></script>
</body>
</html>
