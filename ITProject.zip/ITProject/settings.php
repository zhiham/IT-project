<?php
session_start();
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;
$language = isset($_SESSION['language']) ? $_SESSION['language'] : 'English';
$font_size = isset($_SESSION['font_size']) ? $_SESSION['font_size'] : '16px';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title data-translate="Settings">Settings - SUN ROOM STUDENT PORTAL</title>
    <link rel="stylesheet" href="navigation.css">
    <link rel="stylesheet" href="settings.css">
</head>
<body class="<?= $dark_mode ? 'dark-mode' : '' ?>" style="font-size: <?= $font_size ?>;">

    <nav>
        <div class="navigation">
            <div class="left-section">
                <a href="LoginPage.php"><img class="logo" src="pictures/logo.png"></a>
            </div>
            <div class="middle-section-search">
                <input class="searchbar" type="text" name="search" placeholder="Search">
                <button class="searchimgbutton"><img class="searchimg" src="pictures/icons/search.jpg"></button>
            </div>
            <div class="right-section-Attendance">
                <div class="navigation-div">
                    <a href="Timetable.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/timetable.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Timetable">Timetable</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentAttendance.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/attendance.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Attendance">Attendance</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentDashboard.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/dashboard.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Dashboard">Dashboard</span>
                </div>
                <div class="navigation-div">
                    <a href="Profile.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/more.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Profile">Profile</span>
                </div>
            </div>
        </div>
    </nav>

    <div class="settings-container">
        <h1 data-translate="Settings">Settings</h1>

        <section class="dark-mode-toggle">
            <h2 data-translate="Dark Mode">Dark Mode</h2>
            <label class="switch">
                <input type="checkbox" id="dark-mode-toggle" <?= $dark_mode ? 'checked' : '' ?>>
                <span class="slider round"></span>
            </label>
            <span data-translate="Enable Dark Mode">Enable Dark Mode</span>
        </section>

        <section class="language-change">
            <h2 data-translate="Language">Language</h2>
            <label for="language-select" data-translate="Select Language:">Select Language:</label>
            <select id="language-select">
                <option value="English" <?= $language === 'English' ? 'selected' : '' ?>>English</option>
                <option value="Spanish" <?= $language === 'Spanish' ? 'selected' : '' ?>>Spanish</option>
                <option value="French" <?= $language === 'French' ? 'selected' : '' ?>>French</option>
                <option value="Bahasa" <?= $language === 'Bahasa' ? 'selected' : '' ?>>Bahasa Malaysia</option>
                <option value="Chinese" <?= $language === 'Chinese' ? 'selected' : '' ?>>简体中文 (Chinese)</option>
                <option value="Japanese" <?= $language === 'Japanese' ? 'selected' : '' ?>>日本語 (Japanese)</option>
                <option value="Korean" <?= $language === 'Korean' ? 'selected' : '' ?>>한국어 (Korean)</option>
                <option value="Russian" <?= $language === 'Russian' ? 'selected' : '' ?>>Русский (Russian)</option>
                <option value="Arabic" <?= $language === 'Arabic' ? 'selected' : '' ?>>العربية (Arabic)</option>
                <option value="Hindi" <?= $language === 'Hindi' ? 'selected' : '' ?>>हिन्दी (Hindi)</option>
                <option value="Indonesian" <?= $language === 'Indonesian' ? 'selected' : '' ?>>Bahasa Indonesia</option>
            </select>
        </section>

        <section class="font-size-change">
            <h2 data-translate="Font Size">Font Size</h2>
            <label for="font-size-slider" data-translate="Adjust Font Size:">Adjust Font Size:</label>
            <input type="range" id="font-size-slider" min="12" max="24" step="1" value="<?= (int)str_replace('px', '', $font_size) ?>">
        </section>
		



        <button class="save-button" id="save-settings" data-translate="Save Settings">Save Settings</button>
    </div>

    <script src="settings.js"></script>
</body>
</html>
