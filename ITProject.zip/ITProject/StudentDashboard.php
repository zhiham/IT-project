<?php
session_start();
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;
$language = isset($_SESSION['language']) ? $_SESSION['language'] : 'English';
$font_size = isset($_SESSION['font_size']) ? $_SESSION['font_size'] : '16px';
?>

<!DOCTYPE html>
<html>
<head>
    <title data-translate="SUN ROOM STUDENT PORTAL">SUN ROOM STUDENT PORTAL</title>
    <link rel="stylesheet" href="mainpage.css">
    <link rel="stylesheet" href="navigation.css">
    <link rel="stylesheet" href="studentcard.css">
    <link rel="stylesheet" href="studentdashboard.css">
	<link rel="stylesheet" href="settings.css">
	
	<script>
  const savedFontSize = localStorage.getItem('fontSize') || '16px';
  document.documentElement.style.fontSize = savedFontSize;
</script>
</head>
<body class="<?= $dark_mode ? 'dark-mode' : '' ?>" style="font-size: <?= $font_size ?>;">
    <nav>
        <div class="navigation">
            <div class="left-section">
                <a href="LoginPage.php"><img class="logo" src="pictures/logo.png"></a>
            </div>

            <div class="middle-section-search">
                <input class="searchbar" type="text" name="search" placeholder="Search">
                <button class="searchimgbutton">
                    <img class="searchimg" src="pictures/icons/search.jpg">
                </button>
            </div>

            <div class="right-section-Attendance">
                <div class="navigation-div">
                    <a href="Timetable.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/timetable.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Timetable">Timetable</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentAttendance.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/attendance.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Attendance">Attendance</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentDashboard.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/dashboard.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Dashboard">Dashboard</span>
                </div>
                <div class="navigation-div">
                    <a href="Profile.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/more.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Profile">Profile</span>
                </div>
            </div>
        </div>
    </nav>

    <br>

    <div class="container">
        <div class="content-row">
            <div class="left-column">
                <div class="dashboard-wrapper">
                    <div class="buttons-box">
                        <div class="buttonDash">
                            <a href="StudentAttendanceOTP.php"><button class="button-77" data-translate="Sign Attendance">Sign Attendance</button></a>
                        </div>
                        <div class="buttonDash">
                            <a href="https://elearn.sunway.edu.my/"><button class="button-77" data-translate="E-learn">E-learn</button></a>
                        </div>
                        <div class="buttonDash">
                            <a href="https://student.sunway.edu.my/campus-life/student-support"><button class="button-77" data-translate="Support">Support</button></a>
                        </div>
                        <div class="buttonDash">
                            <a href="ClassroomFinder.php"><button class="button-77" data-translate="Classroom Finder">Classroom Finder</button></a>
                        </div>
                    </div>
                </div>

                <div class="schedule-section">
                    <h2 class="schedule-header" data-translate="Weekly Class Schedule">🗓️ Weekly Class Schedule</h2>

                    <div class="schedule-day-card">
                        <div class="schedule-day-header">Monday, 20 May 2025</div>
                        <div class="schedule-subject">
                            <p><strong data-translate="Subject:">Subject:</strong> ELEMENTARY CALCULUS</p>
                            <p><strong data-translate="Classroom:">Classroom:</strong> Auditorium 3</p>
                            <p><strong data-translate="Time:">Time:</strong> 08:00 AM – 09:00 AM</p>
                        </div>
                        <div class="schedule-subject">
                            <p><strong data-translate="Subject:">Subject:</strong> COMPUTER SYSTEM ARCHITECTURE</p>
                            <p><strong data-translate="Classroom:">Classroom:</strong> Auditorium 3</p>
                            <p><strong data-translate="Time:">Time:</strong> 12:00 PM – 01:00 PM</p>
                        </div>
                    </div>

                    <div class="schedule-day-card">
                        <div class="schedule-day-header">Tuesday, 21 May 2025</div>
                        <div class="schedule-subject">
                            <p><strong data-translate="Subject:">Subject:</strong> PROFESSIONAL ISSUES IN IT</p>
                            <p><strong data-translate="Classroom:">Classroom:</strong> Auditorium 3</p>
                            <p><strong data-translate="Time:">Time:</strong> 01:00 PM – 02:00 PM</p>
                        </div>
                        <div class="schedule-subject">
                            <p><strong data-translate="Subject:">Subject:</strong> NETWORK ADMIN & SECURITY</p>
                            <p><strong data-translate="Classroom:">Classroom:</strong> Auditorium 3</p>
                            <p><strong data-translate="Time:">Time:</strong> 02:00 PM – 03:00 PM</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="right-column">
                <div class="profile-div">
                    <div class="profile-card">
                        <div class="profile-header">Kishen Austin Nair 2304885</div>
                        <div class="profile-body">
                            <div class="profile-photo">
                                <img src="pictures/studentpics/kishenAN.jpg" alt="Profile Photo">
                            </div>
                            <div class="profile-info">
                                <p><b data-translate="Programme:">Programme:</b> Diploma In Information Technology</p>
                                <p><b data-translate="Intake:">Intake:</b> April 2024</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="news-section">
                    <h2 class="news-title" data-translate="Latest News">📢 Latest News</h2>

                    <div class="news-scrollable">
                        <div class="news-card">
                            <h3 class="news-item-title" data-translate="Midterm Exams Begin Soon">🎓 Midterm Exams Begin Soon</h3>
                            <p class="news-date" >15 May 2025</p>
                            <p class="news-text" data-translate="Midterm Exams Description">
                                Midterm exams will start from 27 May 2025. Check your timetable and consult your lecturers for topics.
                            </p>
                        </div>

                        <div class="news-card">
                            <h3 class="news-item-title" data-translate="New Resources on E-learn">📚 New Resources on E-learn</h3>
                            <p class="news-date">13 May 2025</p>
                            <p class="news-text" data-translate="New Resources Description">
                                New study materials and tutorials for DDS2133 & DIT1233 are now available on e-learn.
                            </p>
                        </div>

                        <div class="news-card">
                            <h3 class="news-item-title" data-translate="Portal Maintenance">🔧 Portal Maintenance</h3>
                            <p class="news-date">10 May 2025</p>
                            <p class="news-text" data-translate="Portal Maintenance Description">
                                The portal will be unavailable on 1 June due to scheduled maintenance. Please download your files early.
                            </p>
                        </div>

                        <div class="news-card">
                            <h3 class="news-item-title" data-translate="Leadership Workshop Registration">🎤 Leadership Workshop Registration</h3>
                            <p class="news-date">9 May 2025</p>
                            <p class="news-text" data-translate="Leadership Workshop Description">
                                Sign up for the leadership workshop happening on 30 May at the Main Hall. Limited seats available.
                            </p>
                        </div>

                        <div class="news-card">
                            <h3 class="news-item-title" data-translate="Coding Competition Results">🏆 Coding Competition Results</h3>
                            <p class="news-date">7 May 2025</p>
                            <p class="news-text" data-translate="Coding Results Description">
                                Congratulations to Team Hexa for winning the intercollege coding challenge! Full results on student portal.
                            </p>
                        </div>

                        <div class="news-card">
                            <h3 class="news-item-title" data-translate="Shuttle Bus Timetable Updated">🚌 Shuttle Bus Timetable Updated</h3>
                            <p class="news-date">5 May 2025</p>
                            <p class="news-text" data-translate="Shuttle Bus Description">
                                New shuttle bus schedule available starting next week. Check the transport section for updated times.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="logout-button-div">
                    <a href="settings.php"><button class="button-44" role="button" data-translate="Settings">Settings</button></a>
                    <button class="button-44" role="button" data-translate="Logout">Logout</button>
                </div>
            </div>
        </div>
    </div>

    <script src="settings.js"></script>
</body>
</html>
