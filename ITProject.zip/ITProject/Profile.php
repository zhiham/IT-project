<?php
session_start();
$dark_mode = isset($_SESSION['dark_mode']) ? $_SESSION['dark_mode'] : false;
$language = isset($_SESSION['language']) ? $_SESSION['language'] : 'English';
$font_size = isset($_SESSION['font_size']) ? $_SESSION['font_size'] : '16px';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title data-translate="Profile - SUN ROOM STUDENT PORTAL">Profile - SUN ROOM STUDENT PORTAL</title>
    <link rel="stylesheet" href="mainpage.css">
    <link rel="stylesheet" href="navigation.css">
    <link rel="stylesheet" href="Profile.css">
    <link rel="stylesheet" href="studentdashboard.css">
	<link rel="stylesheet" href="settings.css">
</head>

<body class="<?= $dark_mode ? 'dark-mode' : '' ?>" style="font-size: <?= $font_size ?>;">

    <nav>
        <div class="navigation">
            <div class="left-section">
                <a href="LoginPage.php"><img class="logo" src="pictures/logo.png" alt="Logo"></a>
            </div>
            <div class="middle-section-search">
                <input class="searchbar" type="text" name="search" placeholder="Search">
                <button class="searchimgbutton">
                    <img class="searchimg" src="pictures/icons/search.jpg">
                </button>
            </div>
            <div class="right-section-Attendance">
                <div class="navigation-div">
                    <a href="Timetable.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/timetable.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Timetable">Timetable</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentAttendance.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/attendance.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Attendance">Attendance</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentDashboard.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/dashboard.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Dashboard">Dashboard</span>
                </div>
                <div class="navigation-div">
                    <a href="Profile.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/profile.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Profile">Profile</span>
                </div>
            </div>
        </div>
    </nav>

    <br>

    <div class="profile-page">
        <div class="profile-title">
            <h1>KISHEN AUSTIN NAIR</h1>
            <h3>2304885</h3>
        </div>

        <div class="profile-picture">
            <div class="profile-photo">
                <img src="pictures/studentpics/kishenAN.jpg" alt="Profile Photo">
            </div>

            <div class="profile-info">
                <p><b data-translate="Programme:">Programme:</b> <span data-translate="Diploma In Information Technology">Diploma In Information Technology</span></p>
                <p><b data-translate="Intake:">Intake:</b> <span data-translate="April 2024">April 2024</span></p>
                <p><b data-translate="Country:">Country:</b> <span data-translate="Malaysia">Malaysia</span></p>
                <p><b data-translate="Semester:">Semester:</b> <span>4</span></p>
                <p><b data-translate="Semester Period:">Semester Period:</b> <span data-translate="14-APR-2025 - 07-AUGUST-2025">14-APR-2025 - 07-AUGUST-2025</span></p>
            </div>
        </div>
    </div>

    <div class="news-box">
        <div class="logout-button-div">
            <a href="settings.php"><button class="button-44" role="button" data-translate="Settings">Settings</button></a>
            <a href="LoginPage.php"><button class="button-44" role="button" data-translate="Logout">Logout</button></a>
        </div>
    </div>

    <script src="settings.js"></script>
</body>
</html>
