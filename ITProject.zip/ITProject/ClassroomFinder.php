<?php
session_start();
$dark_mode = $_SESSION['dark_mode'] ?? false;
$language = $_SESSION['language'] ?? 'English';
$font_size = $_SESSION['font_size'] ?? '16px';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title data-translate="Classroom Finder">Classroom Finder</title>
    <link rel="stylesheet" href="mainpage.css">
    <link rel="stylesheet" href="navigation.css">
    <link rel="stylesheet" href="ClassroomFinder.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="<?= $dark_mode ? 'dark-mode' : '' ?>" style="font-size: <?= $font_size ?>;">
    <nav>
        <div class="navigation">
            <div class="left-section">
                <a href="LoginPage.php"><img class="logo" src="pictures/logo.png"></a>
            </div>

            <div class="middle-section-search">
                <input class="searchbar" type="text" name="search" placeholder="Search">
                <button class="searchimgbutton">
                    <img class="searchimg" src="pictures/icons/search.jpg">
                </button>
            </div>

            <div class="right-section-Attendance">
                <div class="navigation-div">
                    <button class="navigation-button"><a href="Timetable.php"><img class="navpic" src="pictures/icons/timetable.png"></a></button>
                    <span class="navigation-text-attendance" data-translate="Timetable">Timetable</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentAttendance.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/attendance.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Attendance">Attendance</span>
                </div>
                <div class="navigation-div">
                    <a href="StudentDashboard.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/dashboard.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Dashboard">Dashboard</span>
                </div>
                <div class="navigation-div">
                    <a href="Profile.php"><button class="navigation-button"><img class="navpic" src="pictures/icons/more.png"></button></a>
                    <span class="navigation-text-attendance" data-translate="Profile">Profile</span>
                </div>
            </div>
        </div>
    </nav>

    <div class="classroom-container">
        <div class="filters">
            <select id="date-filter" class="filter-dropdown">
                <option value="" data-translate="Select Date">Select Date</option>
                <option value="2025-05-20">20 May 2025</option>
                <option value="2025-05-21">21 May 2025</option>
                <option value="2025-05-22">22 May 2025</option>
            </select>

            <select id="day-filter" class="filter-dropdown">
                <option value="" data-translate="Select Day">Select Day</option>
                <option value="Monday" data-translate="Monday">Monday</option>
                <option value="Tuesday" data-translate="Tuesday">Tuesday</option>
                <option value="Wednesday" data-translate="Wednesday">Wednesday</option>
                <option value="Thursday" data-translate="Thursday">Thursday</option>
                <option value="Friday" data-translate="Friday">Friday</option>
            </select>
        </div>

        <div class="classroom-list">
            <h2 id="classroom-heading" data-translate="Classrooms Available on 20 May 2025 (Monday)">Classrooms Available on 20 May 2025 (Monday)</h2>

            <!-- Classroom 1 -->
            <div class="classroom-box">
                <h3 class="classroom-name">Auditorium 1</h3>
                <div class="available-times">
                    <p><strong data-translate="Available Time Slots:">Available Time Slots:</strong></p>
                    <ul>
                        <li>08:00 AM - 10:00 AM</li>
                        <li>02:00 PM - 04:00 PM</li>
                    </ul>
                </div>
            </div>

            <!-- Classroom 2 -->
            <div class="classroom-box">
                <h3 class="classroom-name">Classroom 202</h3>
                <div class="available-times">
                    <p><strong data-translate="Available Time Slots:">Available Time Slots:</strong></p>
                    <ul>
                        <li>09:00 AM - 11:00 AM</li>
                        <li>01:00 PM - 03:00 PM</li>
                    </ul>
                </div>
            </div>

            <!-- Classroom 3 -->
            <div class="classroom-box">
                <h3 class="classroom-name">NW-TR1-2</h3>
                <div class="available-times">
                    <p><strong data-translate="Available Time Slots:">Available Time Slots:</strong></p>
                    <ul>
                        <li>10:00 AM - 12:00 PM</li>
                        <li>03:00 PM - 05:00 PM</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="settings.js"></script>
</body>
</html>
